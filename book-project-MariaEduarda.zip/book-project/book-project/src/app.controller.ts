import { Controller, Body, Get, Post, Delete, Param } from '@nestjs/common';
import { AppService } from './app.service';
import { book } from './books/schemas/books.schema';
import { createBooks } from './dto/createbook';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Post()
  async create(@Body() createBooks: createBooks) {
    await this.appService.create(createBooks);
  }
}
