export class createBooks {
    readonly titulo: string;
    readonly autor: number;
    readonly gereno: string;
    readonly preco: string;
  }