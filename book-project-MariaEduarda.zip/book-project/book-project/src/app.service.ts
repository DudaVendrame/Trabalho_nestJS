import { Injectable } from '@nestjs/common';
import { createBooks } from './dto/createbook';
import { book } from './books/schemas/books.schema';
import { AppModule } from './app.module';

@Injectable()
export class AppService {
 async create(createBooks: createBooks): Promise<void> {
  console.log('Seu novo produto foi criado', createBooks);
 }

}

