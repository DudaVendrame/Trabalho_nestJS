import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

export type bookSchema = HydratedDocument<book>;

@Schema()
export class book {
  @Prop()
  titulo: string;

  @Prop()
  autor: string;

  @Prop()
  genero: string;
  
  @Prop()
  preco: string;
}

export const CatSchema = SchemaFactory.createForClass(book);